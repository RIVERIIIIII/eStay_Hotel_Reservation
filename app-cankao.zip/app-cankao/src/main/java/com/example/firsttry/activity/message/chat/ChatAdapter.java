package com.example.firsttry.activity.message.chat;

import android.graphics.Color;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.firsttry.R;
import com.example.firsttry.utils.TimeUtils;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int VIEW_TYPE_MESSAGE_SENT = 1;
    private static final int VIEW_TYPE_MESSAGE_RECEIVED = 2;
    private static final int VIEW_TYPE_FAQ = 3;

    private List<ChatMessage> chatMessageList;
    private OnFaqClickListener faqClickListener;

    public interface OnFaqClickListener {
        void onQuestionClick(String question);
    }

    public ChatAdapter(List<ChatMessage> chatMessageList) {
        this.chatMessageList = chatMessageList;
    }

    public void setOnFaqClickListener(OnFaqClickListener listener) {
        this.faqClickListener = listener;
    }

    @Override
    public int getItemViewType(int position) {
        ChatMessage message = chatMessageList.get(position);
        if (message.getType() == 1) {
            return VIEW_TYPE_FAQ;
        }
        if (message.isSentByMe()) {
            return VIEW_TYPE_MESSAGE_SENT;
        } else {
            return VIEW_TYPE_MESSAGE_RECEIVED;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (viewType == VIEW_TYPE_MESSAGE_SENT) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_chat_sent, parent, false);
            return new SentMessageHolder(view);
        } else if (viewType == VIEW_TYPE_MESSAGE_RECEIVED) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_chat_received, parent, false);
            return new ReceivedMessageHolder(view);
        } else {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_chat_faq, parent, false);
            return new FaqViewHolder(view, faqClickListener);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ChatMessage message = chatMessageList.get(position);
        switch (holder.getItemViewType()) {
            case VIEW_TYPE_MESSAGE_SENT:
                ((SentMessageHolder) holder).bind(message);
                break;
            case VIEW_TYPE_MESSAGE_RECEIVED:
                ((ReceivedMessageHolder) holder).bind(message);
                break;
            case VIEW_TYPE_FAQ:
                ((FaqViewHolder) holder).bind(message);
                break;
        }
    }

    @Override
    public int getItemCount() {
        return chatMessageList == null ? 0 : chatMessageList.size();
    }

    // ViewHolder for "Sent" messages
    private static class SentMessageHolder extends RecyclerView.ViewHolder {
        TextView messageText, timeText;

        SentMessageHolder(View itemView) {
            super(itemView);
            messageText = itemView.findViewById(R.id.text_message_body_sent);
            timeText = itemView.findViewById(R.id.text_message_time_sent);
        }

        void bind(ChatMessage message) {
            messageText.setText(message.getContent());
            timeText.setText(TimeUtils.formatFriendlyTime(message.getTimestamp()));
        }
    }

    // ViewHolder for "Received" messages
    private static class ReceivedMessageHolder extends RecyclerView.ViewHolder {
        TextView messageText, timeText, nameText;

        ReceivedMessageHolder(View itemView) {
            super(itemView);
            messageText = itemView.findViewById(R.id.text_message_body_received);
            timeText = itemView.findViewById(R.id.text_message_time_received);
            nameText = itemView.findViewById(R.id.text_message_name_received);
        }

        void bind(ChatMessage message) {
            messageText.setText(message.getContent());
            timeText.setText(TimeUtils.formatFriendlyTime(message.getTimestamp()));
        }
    }

    // ViewHolder for FAQ messages
    private static class FaqViewHolder extends RecyclerView.ViewHolder {
        LinearLayout layoutCategories, layoutQuestions;
        OnFaqClickListener listener;
        Map<String, List<String>> faqData;
        String currentCategory = "预订相关";

        FaqViewHolder(View itemView, OnFaqClickListener listener) {
            super(itemView);
            this.listener = listener;
            layoutCategories = itemView.findViewById(R.id.layout_categories);
            layoutQuestions = itemView.findViewById(R.id.layout_questions);
            initFaqData();
        }

        private void initFaqData() {
            faqData = new LinkedHashMap<>();
            faqData.put("预订相关", Arrays.asList(
                    "如何通过易宿平台搜索并预订特定城市的酒店？",
                    "订单提交后，多久可以收到确认短信或邮件？",
                    "为什么显示的房价与最终支付时的价格不一致？",
                    "是否可以代他人预订酒店？入住人姓名填错如何处理？",
                    "预订时提示“房源紧张”或“满房”该怎么办？",
                    "如何查看我过往的历史订单记录？"
            ));
            faqData.put("入住须知", Arrays.asList(
                    "酒店的标准入住（Check-in）和退房（Check-out）时间分别是几点？",
                    "办理入住时需要提供哪些有效身份证件？",
                    "由于行程耽搁，凌晨才到达酒店，预订会被取消吗？",
                    "未成年人在没有监护人陪同下可以单独办理入住吗？",
                    "酒店是否允许携带宠物入住？是否需要额外收费？",
                    "入住时是否需要缴纳押金？押金金额通常是多少？"
            ));
            faqData.put("会员服务", Arrays.asList(
                    "如何注册成为易宿会员？不同等级的会员有哪些权益？",
                    "会员积分的有效期是多久？过期后会自动清零吗？",
                    "在预订过程中，如何使用积分抵扣房费？",
                    "会员等级是如何晋升的？“黑金会员”需要满足什么条件？",
                    "积分除了抵扣房费，还可以兑换实物礼品或接送机服务吗？",
                    "忘记会员账号或密码，如何通过绑定手机号找回？"
            ));
            faqData.put("退款政策", Arrays.asList(
                    "如何申请修改订单的入住日期或房型？",
                    "取消预订是否有时间限制？“不可取消”订单可以退款吗？",
                    "订单取消成功后，退款通常在几个工作日内原路退回？",
                    "如果因不可抗力（如航班取消、自然灾害）无法入住，如何申请全额退款？",
                    "未入住且未提前取消，酒店会扣除首晚房费吗？"
            ));
            faqData.put("其他问题", Arrays.asList(
                    "酒店是否提供免费停车场？是否需要提前预订车位？",
                    "酒店早餐的供应时间及具体地点在哪里？",
                    "是否可以申请提前入住或延迟退房？额外费用如何计算？",
                    "如何在线开具电子发票？纸质发票可以邮寄吗？",
                    "酒店是否提供免费接送机或接送站服务？"
            ));
        }

        void bind(ChatMessage message) {
            updateCategories();
            updateQuestions();
        }

        private void updateCategories() {
            layoutCategories.removeAllViews();
            for (String category : faqData.keySet()) {
                TextView tv = new TextView(itemView.getContext());
                tv.setText(category);
                tv.setPadding(dpToPx(16), dpToPx(8), dpToPx(16), dpToPx(8));
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 0, dpToPx(8), 0);
                tv.setLayoutParams(lp);

                if (category.equals(currentCategory)) {
                    tv.setBackgroundResource(R.drawable.bg_faq_category_active);
                    tv.setTextColor(Color.WHITE);
                } else {
                    tv.setBackgroundResource(R.drawable.bg_faq_category_inactive);
                    tv.setTextColor(Color.parseColor("#795548")); // Muted Brown
                }

                tv.setOnClickListener(v -> {
                    currentCategory = category;
                    updateCategories();
                    updateQuestions();
                });
                layoutCategories.addView(tv);
            }
        }

        private void updateQuestions() {
            layoutQuestions.removeAllViews();
            List<String> questions = faqData.get(currentCategory);
            if (questions != null) {
                for (String question : questions) {
                    TextView tv = new TextView(itemView.getContext());
                    tv.setText(question + "  ›");
                    tv.setPadding(dpToPx(16), dpToPx(14), dpToPx(32), dpToPx(14));
                    tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
                    tv.setTextColor(Color.parseColor("#4E342E")); // Dark Brown
                    tv.setBackgroundResource(R.drawable.bg_faq_question_card);
                    tv.setLineSpacing(0, 1.2f);
                    
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    lp.setMargins(0, 0, 0, dpToPx(12));
                    tv.setLayoutParams(lp);

                    tv.setOnClickListener(v -> {
                        if (listener != null) {
                            listener.onQuestionClick(question);
                        }
                    });
                    layoutQuestions.addView(tv);
                }
            }
        }

        private int dpToPx(int dp) {
            return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp,
                    itemView.getContext().getResources().getDisplayMetrics());
        }
    }
}
