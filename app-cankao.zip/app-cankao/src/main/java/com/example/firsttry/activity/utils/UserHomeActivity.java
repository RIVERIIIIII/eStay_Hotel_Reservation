package com.example.firsttry.activity.utils;

import androidx.appcompat.app.AppCompatActivity;

import com.example.firsttry.R;

public class UserHomeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userhome);
    }
}
